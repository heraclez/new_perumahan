<?php

namespace App\Filters;

use CodeIgniter\Filters\FilterInterface;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;

class RoleGuard implements FilterInterface
{
    /**
     * Check if the authenticated user has the required role.
     *
     * @param array|null $arguments
     *
     * @return mixed
     */
    public function before(RequestInterface $request, $arguments = null)
    {
        $session = session();
        
        if (!$session->get('is_admin_logged_in')) {
            return redirect()->to(site_url('admin/login'))->with('error', 'Sesi Anda telah berakhir, silakan login kembali.');
        }

        $userRole = $session->get('admin_role');

        if (!empty($arguments)) {
            // $arguments can be ['Superadmin'] or list of allowed roles
            if (!in_array($userRole, $arguments, true)) {
                return redirect()->to(site_url('admin/dashboard'))->with('error', 'Akses ditolak. Anda tidak memiliki izin untuk mengakses halaman tersebut.');
            }
        }
    }

    public function after(RequestInterface $request, ResponseInterface $response, $arguments = null)
    {
        // Do nothing
    }
}
