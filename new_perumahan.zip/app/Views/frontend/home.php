<?= $this->extend('layouts/frontend') ?>

<?= $this->section('content') ?>

<!-- Hero Section -->
<section class="position-relative py-5 py-lg-6 hero-section">
    <div class="container py-4">
        <div class="row align-items-center g-5">
            <div class="col-lg-6">
                <span class="badge badge-primary-soft px-3 py-2 rounded-pill mb-3">
                    <i class="bi bi-patch-check-fill text-primary me-1"></i> Developer Properti Terpercaya & Legalitas Aman (SHM)
                </span>
                <h1 class="display-4 fw-extrabold text-dark tracking-tight mb-3">
                    <?= esc($settings['company_tagline'] ?? 'Temukan Hunian Impian Keluarga Modern & Asri') ?>
                </h1>
                <p class="lead text-muted mb-4">
                    Kawasan hunian eksklusif dengan fasilitas lengkap, lingkungan hijau, keamanan 24 jam, dan akses cepat menuju jalan tol & stasiun utama.
                </p>
                <div class="d-flex flex-wrap gap-3 mb-5">
                    <a href="<?= site_url('properti') ?>" class="btn btn-primary btn-lg rounded-pill px-4 shadow-sm">
                        <i class="bi bi-houses me-2"></i> Jelajahi Tipe Rumah
                    </a>
                    <a href="<?= site_url('kpr-calculator') ?>" class="btn btn-outline-primary btn-lg rounded-pill px-4">
                        <i class="bi bi-calculator me-2"></i> Hitung Simulasi KPR
                    </a>
                </div>

                <!-- Highlight Stats -->
                <div class="row g-3 border-top pt-4">
                    <div class="col-4">
                        <h4 class="fw-bold text-primary mb-0">100%</h4>
                        <small class="text-muted">Sertifikat SHM</small>
                    </div>
                    <div class="col-4 border-start ps-3">
                        <h4 class="fw-bold text-primary mb-0">DP 0%</h4>
                        <small class="text-muted">Promo Cicilan KPR</small>
                    </div>
                    <div class="col-4 border-start ps-3">
                        <h4 class="fw-bold text-primary mb-0">24/7</h4>
                        <small class="text-muted">Keamanan & CCTV</small>
                    </div>
                </div>
            </div>
            
            <div class="col-lg-6">
                <div class="position-relative">
                    <div class="card card-custom border-0 overflow-hidden shadow-lg p-2 bg-white">
                        <img src="https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=900&auto=format&fit=crop&q=80" alt="Rumah Impian" class="rounded-4 img-fluid" style="max-height: 440px; object-fit: cover;">
                        <div class="p-3 bg-white d-flex justify-content-between align-items-center">
                            <div>
                                <small class="text-muted d-block">Harga Mulai Dari</small>
                                <span class="fs-4 fw-bold text-primary">Rp 650 Juta-an</span>
                            </div>
                            <a href="<?= site_url('properti') ?>" class="btn btn-sm btn-primary rounded-pill px-3">Lihat Detail <i class="bi bi-arrow-right"></i></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Featured Properties Section -->
<section class="py-5 featured-section">
    <div class="container py-4">
        <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-end mb-5">
            <div>
                <span class="text-primary fw-bold text-uppercase small letter-spacing-1">Pilihan Unit Terbaik</span>
                <h2 class="fw-bold text-dark mb-0">Tipe Rumah & Klaster Unggulan</h2>
            </div>
            <a href="<?= site_url('properti') ?>" class="btn btn-outline-primary rounded-pill px-4 mt-3 mt-md-0">
                Lihat Semua Tipe (<?= count($featuredProperties) ?>) <i class="bi bi-arrow-right ms-1"></i>
            </a>
        </div>

        <div class="row g-4">
            <?php if (empty($featuredProperties)): ?>
                <div class="col-12 text-center py-5">
                    <i class="bi bi-house-exclamation fs-1 text-muted"></i>
                    <p class="text-muted mt-2">Belum ada unit properti yang ditambahkan.</p>
                </div>
            <?php else: ?>
                <?php foreach ($featuredProperties as $prop): ?>
                    <div class="col-md-6 col-lg-4">
                        <div class="card card-custom h-100 overflow-hidden bg-white">
                            <div class="position-relative">
                                <?php 
                                $imgSrc = $prop['primary_image'] ?? '';
                                if (empty($imgSrc)) {
                                    $imgSrc = 'https://images.unsplash.com/photo-1580587771525-78b9dba3b914?w=600&auto=format&fit=crop&q=80';
                                } elseif (!str_starts_with($imgSrc, 'http')) {
                                    $imgSrc = base_url('uploads/properties/' . $imgSrc);
                                }
                                ?>
                                <img src="<?= esc($imgSrc) ?>" class="card-img-top" alt="<?= esc($prop['title']) ?>" style="height: 240px; object-fit: cover;">
                                
                                <span class="position-absolute top-0 start-0 m-3 badge <?= $prop['status_badge'] ?? 'bg-success' ?> rounded-pill px-3 py-2 shadow-sm">
                                    <i class="bi bi-tag-fill me-1"></i> <?= esc($prop['status_label'] ?? $prop['status']) ?>
                                </span>

                                <?php if (!empty($prop['is_promo'])): ?>
                                    <button type="button" class="position-absolute top-0 end-0 m-3 badge bg-danger text-white rounded-pill px-3 py-2 border-0 shadow-sm btn-unit-promo-trigger" data-title="<?= esc($prop['title']) ?>" data-price="Rp <?= number_format($prop['harga'], 0, ',', '.') ?>" data-promo-title="<?= esc($prop['promo_title'] ?: 'Promo Spesial Unit') ?>" data-promo-desc="<?= esc($prop['promo_desc'] ?: 'Free BPHTB, Subsidi DP & Angsuran KPR.') ?>" data-slug="<?= esc($prop['slug']) ?>" data-img="<?= esc($imgSrc) ?>" title="Klik untuk lihat promo unit ini">
                                        <i class="bi bi-fire text-warning me-1"></i> PROMO
                                    </button>
                                <?php endif; ?>
                            </div>
                            <div class="card-body p-4 d-flex flex-column">
                                <h5 class="fw-bold card-title mb-1 text-dark"><?= esc($prop['title']) ?></h5>
                                <div class="fs-4 fw-extrabold text-primary mb-3">
                                    Rp <?= number_format($prop['harga'], 0, ',', '.') ?>
                                </div>
                                <p class="text-muted small mb-3 flex-grow-1">
                                    <?= character_limiter(strip_tags($prop['deskripsi'] ?? ''), 100) ?>
                                </p>
                                
                                <div class="bg-light p-2 rounded-3 mb-3 d-flex justify-content-around text-center small text-muted">
                                    <div>
                                        <i class="bi bi-aspect-ratio text-primary d-block fs-6"></i>
                                        <span>LT <?= esc($prop['luas_tanah']) ?> m²</span>
                                    </div>
                                    <div class="border-start"></div>
                                    <div>
                                        <i class="bi bi-building text-primary d-block fs-6"></i>
                                        <span>LB <?= esc($prop['luas_bangunan']) ?> m²</span>
                                    </div>
                                    <div class="border-start"></div>
                                    <div>
                                        <i class="bi bi-door-closed text-primary d-block fs-6"></i>
                                        <span><?= esc($prop['spesifikasi_kamar'] ?: '2 KT / 1 KM') ?></span>
                                    </div>
                                </div>

                                <?php if (!empty($prop['is_promo'])): ?>
                                    <button type="button" class="btn btn-warning btn-sm rounded-pill w-100 fw-bold mb-2 shadow-sm text-dark btn-unit-promo-trigger" data-title="<?= esc($prop['title']) ?>" data-price="Rp <?= number_format($prop['harga'], 0, ',', '.') ?>" data-promo-title="<?= esc($prop['promo_title'] ?: 'Promo Spesial Unit') ?>" data-promo-desc="<?= esc($prop['promo_desc'] ?: 'Free BPHTB, Subsidi DP & Angsuran KPR.') ?>" data-slug="<?= esc($prop['slug']) ?>" data-img="<?= esc($imgSrc) ?>">
                                        <i class="bi bi-gift-fill text-danger me-1"></i> Cek Promo Unit
                                    </button>
                                <?php endif; ?>

                                <div class="d-flex gap-2">
                                    <a href="<?= site_url('properti/' . $prop['slug']) ?>" class="btn btn-primary w-100 rounded-pill py-2">
                                        Lihat Detail
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
</section>

<!-- USP / Keunggulan Kami -->
<section class="py-5 usp-section">
    <div class="container py-4">
        <div class="text-center max-w-2xl mx-auto mb-5">
            <span class="text-primary fw-bold text-uppercase small">Mengapa Memilih Kami</span>
            <h2 class="fw-bold text-dark">Kenyamanan & Nilai Investasi Terbaik</h2>
            <p class="text-muted">Dirancang dengan standar konstruksi tinggi dan tata ruang lingkungan terpadu.</p>
        </div>

        <div class="row g-4">
            <div class="col-md-6 col-lg-3">
                <div class="card card-custom border-0 p-4 h-100 text-center bg-white">
                    <div class="bg-primary text-white rounded-circle d-flex align-items-center justify-content-center mx-auto mb-3" style="width: 60px; height: 60px;">
                        <i class="bi bi-shield-check fs-3"></i>
                    </div>
                    <h5 class="fw-bold">Legalitas 100% Aman</h5>
                    <p class="text-muted small mb-0">Sertifikat Hak Milik (SHM) dan IMB/PBG sudah pecah per unit, siap akad notaris.</p>
                </div>
            </div>
            <div class="col-md-6 col-lg-3">
                <div class="card card-custom border-0 p-4 h-100 text-center bg-white">
                    <div class="bg-primary text-white rounded-circle d-flex align-items-center justify-content-center mx-auto mb-3" style="width: 60px; height: 60px;">
                        <i class="bi bi-geo-alt-fill fs-3"></i>
                    </div>
                    <h5 class="fw-bold">Lokasi Sangat Strategis</h5>
                    <p class="text-muted small mb-0">Hanya 10 menit ke gerbang tol, pusat perbelanjaan, sekolah favorit, dan rumah sakit.</p>
                </div>
            </div>
            <div class="col-md-6 col-lg-3">
                <div class="card card-custom border-0 p-4 h-100 text-center bg-white">
                    <div class="bg-primary text-white rounded-circle d-flex align-items-center justify-content-center mx-auto mb-3" style="width: 60px; height: 60px;">
                        <i class="bi bi-tree-fill fs-3"></i>
                    </div>
                    <h5 class="fw-bold">Eco Green Living</h5>
                    <p class="text-muted small mb-0">Dilengkapi taman bermain tematik, jogging track, saluran underground, dan clubhouse eksklusif.</p>
                </div>
            </div>
            <div class="col-md-6 col-lg-3">
                <div class="card card-custom border-0 p-4 h-100 text-center bg-white">
                    <div class="bg-primary text-white rounded-circle d-flex align-items-center justify-content-center mx-auto mb-3" style="width: 60px; height: 60px;">
                        <i class="bi bi-cash-coin fs-3"></i>
                    </div>
                    <h5 class="fw-bold">Kemudahan KPR</h5>
                    <p class="text-muted small mb-0">Bekerjasama dengan lebih dari 10 bank BUMN & Swasta nasional dengan proses approval cepat.</p>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Call to Action Banner -->
<section class="py-5 text-white position-relative cta-section">
    <div class="container py-4 text-center">
        <h2 class="display-6 fw-bold mb-3 text-white">Siap Memiliki Rumah Impian Anda Hari Ini?</h2>
        <p class="lead mb-4 text-white-50 mx-auto" style="max-width: 650px;">
            Konsultasikan kebutuhan hunian, simulasi KPR gratis, dan jadwalkan kunjungan show unit bersama konsultan properti kami.
        </p>
        <div class="d-flex flex-wrap justify-content-center gap-3">
            <a href="https://wa.me/<?= esc($settings['company_whatsapp'] ?? '') ?>?text=Halo%20<?= urlencode($settings['company_name'] ?? 'Grand Harmoni') ?>,%20saya%20ingin%20jadwal%20survey%20lokasi." target="_blank" class="btn btn-light text-primary btn-lg rounded-pill px-4 fw-bold">
                <i class="bi bi-whatsapp me-2"></i> Jadwalkan Survey Lokasi
            </a>
            <a href="<?= site_url('brochure/download-global') ?>" class="btn btn-outline-light btn-lg rounded-pill px-4">
                <i class="bi bi-file-earmark-pdf me-2"></i> Unduh E-Katalog PDF
            </a>
        </div>
    </div>
</section>

<?= $this->endSection() ?>
