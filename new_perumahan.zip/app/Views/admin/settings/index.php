<?= $this->extend('layouts/admin') ?>

<?= $this->section('content') ?>



<form action="<?= site_url('admin/settings/update') ?>" method="POST" enctype="multipart/form-data">
    <?= csrf_field() ?>

    <div class="row g-4">
        <!-- Left: Identity & Contact -->
        <div class="col-lg-6">
            <!-- Identitas PT / Perusahaan -->
            <div class="card p-4 shadow-sm mb-4">
                <h5 class="fw-bold text-dark mb-3"><i class="bi bi-building text-primary me-2"></i>Identitas Developer & Perumahan</h5>
                
                <div class="mb-3">
                    <label class="form-label">Nama Perusahaan / Proyek <span class="text-danger">*</span></label>
                    <input type="text" name="company_name" class="form-control" value="<?= old('company_name', $settings['company_name'] ?? '') ?>" required>
                </div>

                <div class="mb-3">
                    <label class="form-label">Tagline Utama (Slogan)</label>
                    <input type="text" name="company_tagline" class="form-control" value="<?= old('company_tagline', $settings['company_tagline'] ?? '') ?>">
                </div>

                <!-- Logo Perusahaan -->
                <div class="mb-3 p-3 bg-light rounded-3 border">
                    <label class="form-label text-dark mb-1 d-flex align-items-center gap-1">
                        <i class="bi bi-image text-primary"></i> Logo Resmi Perusahaan / Perumahan
                    </label>
                    <p class="small mb-2" style="color: #64748b; font-size: 0.78rem;">
                        Ditampilkan pada Navbar Header, Footer, dan Sidebar Panel Admin. Format PNG transparan atau SVG (Maksimal 3MB).
                    </p>

                    <?php 
                    $currLogo = $settings['company_logo'] ?? '';
                    $hasLogo = !empty($currLogo) && file_exists(FCPATH . 'uploads/settings/' . $currLogo);
                    ?>

                    <?php if ($hasLogo): ?>
                        <div class="d-flex align-items-center gap-3 mb-3 p-2 bg-white rounded-3 border">
                            <div class="bg-light p-2 rounded border d-flex align-items-center justify-content-center" style="width: 100px; height: 60px;">
                                <img src="<?= base_url('uploads/settings/' . esc($currLogo)) ?>" alt="Logo Saat Ini" class="img-fluid" style="max-height: 48px; object-fit: contain;">
                            </div>
                            <div class="flex-grow-1">
                                <div class="small fw-bold text-dark text-truncate"><?= esc($currLogo) ?></div>
                                <div class="form-check mt-1">
                                    <input class="form-check-input" type="checkbox" name="delete_company_logo" value="1" id="deleteLogoCheck">
                                    <label class="form-check-label text-danger small" for="deleteLogoCheck">
                                        <i class="bi bi-trash"></i> Hapus logo saat ini (kembali ke teks default)
                                    </label>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>

                    <label class="form-label small mb-1"><?= $hasLogo ? 'Ganti dengan Logo Baru' : 'Pilih Berkas Logo' ?></label>
                    <input type="file" name="company_logo" id="companyLogoInput" class="form-control" accept="image/png,image/jpeg,image/jpg,image/webp,image/svg+xml">
                    <div id="logoPreviewContainer" class="mt-2 d-none">
                        <small class="d-block mb-1" style="color: #64748b;">Pratinjau Logo Baru:</small>
                        <div class="bg-white p-2 rounded border d-inline-flex align-items-center justify-content-center" style="min-width: 120px; height: 60px;">
                            <img id="logoPreviewImg" src="" alt="Pratinjau Logo" style="max-height: 48px; max-width: 200px; object-fit: contain;">
                        </div>
                    </div>
                </div>

                <div class="mb-3">
                    <label class="form-label">Tentang Singkat Developer (Footer & SEO)</label>
                    <textarea name="company_about" class="form-control" rows="3"><?= old('company_about', $settings['company_about'] ?? '') ?></textarea>
                </div>

                <div class="mb-0">
                    <label class="form-label">Alamat Lengkap / Kantor Pemasaran</label>
                    <textarea name="company_address" class="form-control" rows="2"><?= old('company_address', $settings['company_address'] ?? '') ?></textarea>
                </div>
            </div>

            <!-- Kontak Pemasaran -->
            <div class="card p-4 shadow-sm mb-4">
                <h5 class="fw-bold text-dark mb-3"><i class="bi bi-telephone text-primary me-2"></i>Kontak Resmi Perusahaan</h5>
                
                <div class="row g-3 mb-3">
                    <div class="col-md-6">
                        <label class="form-label">WhatsApp Utama (Format: 628...) <span class="text-danger">*</span></label>
                        <input type="text" name="company_whatsapp" class="form-control" value="<?= old('company_whatsapp', $settings['company_whatsapp'] ?? '') ?>" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Telepon Kantor</label>
                        <input type="text" name="company_phone" class="form-control" value="<?= old('company_phone', $settings['company_phone'] ?? '') ?>">
                    </div>
                </div>

                <div class="mb-0">
                    <label class="form-label">Email Pemasaran</label>
                    <input type="email" name="company_email" class="form-control" value="<?= old('company_email', $settings['company_email'] ?? '') ?>">
                </div>
            </div>

            <!-- Preset Gaya Desain & Animasi (Industrialist vs Brutalist) -->
            <div class="card p-4 shadow-sm mb-4">
                <div class="d-flex align-items-center justify-content-between mb-2">
                    <h5 class="fw-bold text-dark mb-0"><i class="bi bi-brush text-primary me-2"></i>Preset Gaya Desain & Animasi Web</h5>
                    <span class="badge bg-primary px-3 py-1.5 rounded-pill">Spring Motion</span>
                </div>
                <p class="small mb-4" style="color: #64748b;">Pilih arah estetika dan karakter fisika pegas (spring) untuk halaman depan website Anda.</p>
                
                <?php $currentTheme = $settings['site_theme_preset'] ?? 'industrialist'; ?>

                <div class="row g-3">
                    <!-- Option 1: Industrialist -->
                    <div class="col-md-6">
                        <label class="d-block h-100 p-3 rounded-3 border <?= $currentTheme === 'industrialist' ? 'border-primary bg-primary-subtle' : 'bg-white' ?>" style="cursor: pointer; transition: all 0.2s ease; border-width: 2px !important;">
                            <div class="d-flex align-items-center justify-content-between mb-2">
                                <span class="fw-bold text-dark d-flex align-items-center gap-2">
                                    <i class="bi bi-gear-wide-connected text-warning fs-5"></i> Industrialist Modern
                                </span>
                                <input type="radio" name="site_theme_preset" value="industrialist" class="form-check-input mt-0" <?= $currentTheme === 'industrialist' ? 'checked' : '' ?>>
                            </div>
                            <p class="small mb-3" style="color: #475569; font-size: 0.82rem; line-height: 1.45;">
                                Blueprint dot-grid, aksen tembaga/amber bronze, font Onest + monospace tech chips, sudut rounded 10px, pegas mekanis presisi.
                            </p>
                            <div class="d-flex gap-1.5 align-items-center flex-wrap">
                                <span class="badge" style="background: #b45309; color: #fff;">#b45309 Copper</span>
                                <span class="badge" style="background: #f5f5f4; color: #1c1917; border: 1px solid #d6d3d1;">Dot-Grid</span>
                                <span class="badge" style="background: #e2e8f0; color: #0f172a;">10px Radius</span>
                            </div>
                        </label>
                    </div>

                    <!-- Option 2: Brutalist -->
                    <div class="col-md-6">
                        <label class="d-block h-100 p-3 border <?= $currentTheme === 'brutalist' ? 'border-dark bg-secondary-subtle' : 'bg-white' ?>" style="cursor: pointer; transition: all 0.2s ease; border: 2.5px solid #000000 !important; border-radius: 0px !important;">
                            <div class="d-flex align-items-center justify-content-between mb-2">
                                <span class="fw-bold text-dark d-flex align-items-center gap-2">
                                    <i class="bi bi-square-fill text-dark fs-5"></i> Architectural Brutalist
                                </span>
                                <input type="radio" name="site_theme_preset" value="brutalist" class="form-check-input mt-0" <?= $currentTheme === 'brutalist' ? 'checked' : '' ?>>
                            </div>
                            <p class="small mb-3" style="color: #000000; font-size: 0.82rem; line-height: 1.45; font-weight: 600;">
                                Sudut 0px tajam, border tebal 3px solid black, bayangan offset 6px keras, font Space Grotesk UPPERCASE, pantulan pegas berbobot berat.
                            </p>
                            <div class="d-flex gap-1.5 align-items-center flex-wrap">
                                <span class="badge" style="background: #000000; color: #fff; border-radius: 0;">#000000 Pitch Black</span>
                                <span class="badge" style="background: #ff3d00; color: #fff; border-radius: 0;">#ff3d00 Hazard</span>
                                <span class="badge" style="background: #fff; color: #000; border: 1.5px solid #000; border-radius: 0;">0px Radius</span>
                            </div>
                        </label>
                    </div>
                </div>
            </div>

            <!-- Palet Warna Dinamis (Dynamic Color Picker) -->
            <div class="card p-4 shadow-sm mb-4">
                <h5 class="fw-bold text-dark mb-3"><i class="bi bi-palette text-primary me-2"></i>Palet Warna Kustom</h5>
                <p class="small mb-3" style="color: #64748b;">Warna aksen tombol dan sorotan pada website.</p>
                
                <div class="row g-3">
                    <div class="col-md-6">
                        <label class="form-label">Warna Utama (Primary Color) <span class="text-danger">*</span></label>
                        <div class="input-group">
                            <input type="color" class="form-control form-control-color" id="primaryColorPicker" value="<?= old('primary_color', $settings['primary_color'] ?? '#1e3a8a') ?>" title="Pilih warna">
                            <input type="text" name="primary_color" id="primaryColorText" class="form-control fw-bold" value="<?= old('primary_color', $settings['primary_color'] ?? '#1e3a8a') ?>" required>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Warna Sekunder (Secondary Color) <span class="text-danger">*</span></label>
                        <div class="input-group">
                            <input type="color" class="form-control form-control-color" id="secondaryColorPicker" value="<?= old('secondary_color', $settings['secondary_color'] ?? '#0d9488') ?>" title="Pilih warna">
                            <input type="text" name="secondary_color" id="secondaryColorText" class="form-control fw-bold" value="<?= old('secondary_color', $settings['secondary_color'] ?? '#0d9488') ?>" required>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Right: Promo Modal & VA & Global Brochure -->
        <div class="col-lg-6">
            <!-- Promo Modal Pop-up -->
            <div class="card p-4 shadow-sm mb-4">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h5 class="fw-bold text-dark mb-0"><i class="bi bi-megaphone text-danger me-2"></i>Promo Pop-up Modal (Beranda)</h5>
                    <div class="form-check form-switch">
                        <input class="form-check-input" type="checkbox" role="switch" id="promoToggle" name="promo_modal_active" value="1" <?= ($settings['promo_modal_active'] ?? '0') === '1' ? 'checked' : '' ?>>
                        <label class="form-check-label fw-bold small" for="promoToggle">Aktifkan Pop-up</label>
                    </div>
                </div>
                
                <div class="mb-3">
                    <label class="form-label">Judul Banner Promo</label>
                    <input type="text" name="promo_modal_title" class="form-control" value="<?= old('promo_modal_title', $settings['promo_modal_title'] ?? '') ?>" placeholder="Contoh: Promo Launching Cluster Lavender">
                </div>

                <div class="mb-3">
                    <label class="form-label">Deskripsi / Detail Promo</label>
                    <textarea name="promo_modal_desc" class="form-control" rows="2"><?= old('promo_modal_desc', $settings['promo_modal_desc'] ?? '') ?></textarea>
                </div>

                <div class="mb-3">
                    <label class="form-label">Teks Tombol Aksi</label>
                    <input type="text" name="promo_modal_btn_text" class="form-control" value="<?= old('promo_modal_btn_text', $settings['promo_modal_btn_text'] ?? 'Klaim Promo Sekarang via WA') ?>">
                </div>

                <div class="mb-3">
                    <label class="form-label">URL Gambar Promo (Atau Unggah File)</label>
                    <input type="text" name="promo_modal_image_url" class="form-control mb-2" placeholder="https://..." value="<?= old('promo_modal_image', $settings['promo_modal_image'] ?? '') ?>">
                    <input type="file" name="promo_image_file" class="form-control" accept="image/*">
                </div>
            </div>

            <!-- Virtual Assistant Widget & n8n AI Chatbot Integration -->
            <div class="card p-4 shadow-sm mb-4">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h5 class="fw-bold text-dark mb-0"><i class="bi bi-robot text-primary me-2"></i>Asisten Virtual &amp; AI Chatbot (n8n)</h5>
                    <span class="badge bg-danger px-3 py-1 rounded-pill"><i class="bi bi-diagram-3-fill me-1"></i> Powered by n8n Workflow</span>
                </div>
                
                <div class="row g-3 mb-3">
                    <div class="col-md-6">
                        <label class="form-label">Nama Asisten Virtual</label>
                        <input type="text" name="va_name" class="form-control" value="<?= old('va_name', $settings['va_name'] ?? 'Sarah - Konsultan Properti') ?>">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Nomor WhatsApp VA</label>
                        <input type="text" name="va_phone" class="form-control" value="<?= old('va_phone', $settings['va_phone'] ?? '6281234567890') ?>" placeholder="6281234567890">
                    </div>
                </div>

                <!-- n8n Webhook Configuration Box -->
                <div class="p-3 bg-light rounded-3 border">
                    <div class="d-flex justify-content-between align-items-center mb-2">
                        <label class="form-label text-dark mb-0"><i class="bi bi-link-45deg text-danger me-1"></i> n8n Webhook URL Chatbot</label>
                        <span class="badge bg-danger text-white" style="font-size: 0.7rem;">n8n Cloud / Self-Hosted</span>
                    </div>
                    <input type="url" name="n8n_webhook_url" class="form-control font-monospace small mb-2" placeholder="https://ercy.app.n8n.cloud/webhook/.../chat" value="<?= old('n8n_webhook_url', $settings['n8n_webhook_url'] ?? 'https://ercy.app.n8n.cloud/webhook/a3da6735-771c-435f-b4c8-c9ae179329f0/chat') ?>" required>
                    <small class="d-block" style="color: #64748b; font-size: 0.75rem;">
                        <i class="bi bi-info-circle text-primary me-1"></i>
                        Seluruh pesan chat pengunjung dikirimkan secara otomatis ke webhook n8n dengan data: <code>{"chatInput": "...", "sessionId": "...", "user_name": "..."}</code>.
                        <br><strong class="text-danger">Penting:</strong> Pastikan toggle workflow di editor n8n berada dalam status <strong>Active</strong>.
                    </small>
                </div>
            </div>

            <!-- Global Brochure PDF (Fallback) -->
            <div class="card p-4 shadow-sm mb-4">
                <h5 class="fw-bold text-dark mb-3"><i class="bi bi-file-earmark-pdf text-danger me-2"></i>Brosur Global Katalog Perumahan</h5>
                <p class="small" style="color: #64748b;">File ini dijadikan fallback download otomatis jika calon pembeli mengunduh brosur pada unit yang belum memiliki brosur PDF spesifik.</p>
                
                <?php if (!empty($settings['global_brochure_pdf'])): ?>
                    <div class="alert alert-info py-2 px-3 small d-flex align-items-center justify-content-between mb-3">
                        <span class="text-truncate fw-medium"><i class="bi bi-file-pdf"></i> <?= esc($settings['global_brochure_pdf']) ?></span>
                        <a href="<?= base_url('uploads/brochures/' . $settings['global_brochure_pdf']) ?>" target="_blank" class="fw-bold text-decoration-none">Unduh / Cek File</a>
                    </div>
                <?php endif; ?>

                <label class="form-label">Unggah Brosur Global Baru (.PDF, max 10MB)</label>
                <input type="file" name="global_brochure_pdf" class="form-control" accept=".pdf">
            </div>

            <div class="d-grid">
                <button type="submit" class="btn btn-primary btn-lg rounded-pill fw-bold shadow-sm">
                    <i class="bi bi-check2-circle me-1"></i> Simpan Seluruh Pengaturan Web & Refresh Cache
                </button>
            </div>
        </div>
    </div>
</form>

<?= $this->endSection() ?>

<?= $this->section('scripts') ?>
<script>
    $('#primaryColorPicker').on('input', function() {
        $('#primaryColorText').val($(this).val());
    });
    $('#primaryColorText').on('input', function() {
        $('#primaryColorPicker').val($(this).val());
    });

    $('#secondaryColorPicker').on('input', function() {
        $('#secondaryColorText').val($(this).val());
    });
    $('#secondaryColorText').on('input', function() {
        $('#secondaryColorPicker').val($(this).val());
    });

    // Company Logo Preview
    $('#companyLogoInput').on('change', function(e) {
        const file = e.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = function(event) {
                $('#logoPreviewImg').attr('src', event.target.result);
                $('#logoPreviewContainer').removeClass('d-none');
            }
            reader.readAsDataURL(file);
        } else {
            $('#logoPreviewContainer').addClass('d-none');
        }
    });

    // Sync localStorage theme preview when saved
    $('form').on('submit', function() {
        const selectedTheme = $('input[name="site_theme_preset"]:checked').val();
        if (selectedTheme) {
            localStorage.setItem('site_theme_preset_preview', selectedTheme);
        }
    });
</script>
<?= $this->endSection() ?>
