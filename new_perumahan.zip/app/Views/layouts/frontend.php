<?php
$primary = $settings['primary_color'] ?? '#1e3a8a';
$secondary = $settings['secondary_color'] ?? '#0d9488';

// Function to convert hex to rgb
function hexToRgb($hex) {
    $hex = ltrim($hex, '#');
    if (strlen($hex) == 3) {
        $hex = $hex[0].$hex[0].$hex[1].$hex[1].$hex[2].$hex[2];
    }
    $r = hexdec(substr($hex, 0, 2));
    $g = hexdec(substr($hex, 2, 2));
    $b = hexdec(substr($hex, 4, 2));
    return "$r, $g, $b";
}

$primaryRgb = hexToRgb($primary);
$secondaryRgb = hexToRgb($secondary);
$companyName = $settings['company_name'] ?? 'Grand Harmoni Residence';
$companyTagline = $settings['company_tagline'] ?? 'Hunian Modern, Asri & Nyaman';
$companyLogo = $settings['company_logo'] ?? '';
$companyPhone = $settings['company_phone'] ?? '021-5558989';
$companyWa = $settings['company_whatsapp'] ?? '6281234567890';
$companyEmail = $settings['company_email'] ?? 'marketing@perumahan.com';
$companyAddress = $settings['company_address'] ?? 'Jakarta Barat, Indonesia';
$vaName = $settings['va_name'] ?? 'Sarah - Konsultan Properti';
$vaPhone = $settings['va_phone'] ?? $companyWa;
$siteThemePreset = $settings['site_theme_preset'] ?? 'industrialist';
?>
<!DOCTYPE html>
<html lang="id" data-theme-preset="<?= esc($siteThemePreset) ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= esc($title ?? $companyName) ?></title>
    <meta name="description" content="<?= esc($meta_description ?? $companyTagline) ?>">
    
    <?php if (!empty($companyLogo) && file_exists(FCPATH . 'uploads/settings/' . $companyLogo)): ?>
        <link rel="icon" href="<?= base_url('uploads/settings/' . esc($companyLogo)) ?>">
    <?php endif; ?>

    <!-- Open Graph Dynamic Meta -->
    <?= $this->renderSection('og_tags') ?>
    <?php if (!$this->renderSection('og_tags')): ?>
        <meta property="og:type" content="website">
        <meta property="og:title" content="<?= esc($title ?? $companyName) ?>">
        <meta property="og:description" content="<?= esc($meta_description ?? $companyTagline) ?>">
        <meta property="og:url" content="<?= current_url() ?>">
        <meta property="og:site_name" content="<?= esc($companyName) ?>">
    <?php endif; ?>

    <!-- Fonts & Icons -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;500;600;700&family=Onest:wght@400;500;600;700;800;900&family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=Space+Grotesk:wght@500;600;700;800;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Dynamic Theme Color Override -->
    <style>
        :root {
            --bs-primary: <?= $primary ?>;
            --bs-primary-rgb: <?= $primaryRgb ?>;
            --bs-secondary: <?= $secondary ?>;
            --bs-secondary-rgb: <?= $secondaryRgb ?>;
            --theme-primary: <?= $primary ?>;
            --theme-secondary: <?= $secondary ?>;
        }

        body {
            font-family: 'Plus Jakarta Sans', -apple-system, BlinkMacSystemFont, sans-serif;
            color: #334155;
            background-color: #f8fafc;
            overflow-x: hidden;
        }

        .bg-primary { background-color: var(--bs-primary) !important; }
        .text-primary { color: var(--bs-primary) !important; }
        .border-primary { border-color: var(--bs-primary) !important; }
        
        .btn-primary {
            background-color: var(--bs-primary) !important;
            border-color: var(--bs-primary) !important;
            color: #ffffff !important;
            font-weight: 600;
            transition: all 0.25s ease;
        }
        .btn-primary:hover, .btn-primary:focus {
            filter: brightness(0.88);
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(var(--bs-primary-rgb), 0.35);
        }

        .btn-secondary {
            background-color: var(--bs-secondary) !important;
            border-color: var(--bs-secondary) !important;
            color: #ffffff !important;
            font-weight: 600;
        }
        .btn-secondary:hover {
            filter: brightness(0.9);
        }

        .btn-outline-primary {
            color: var(--bs-primary) !important;
            border-color: var(--bs-primary) !important;
            font-weight: 600;
        }
        .btn-outline-primary:hover {
            background-color: var(--bs-primary) !important;
            color: #ffffff !important;
        }

        .badge-primary-soft {
            background-color: rgba(var(--bs-primary-rgb), 0.12);
            color: var(--bs-primary);
            font-weight: 600;
        }

        .navbar-brand {
            font-weight: 800;
            letter-spacing: -0.5px;
            color: var(--bs-primary) !important;
        }

        .card-custom {
            border: 1px solid #e2e8f0;
            border-radius: 14px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.04);
            transition: transform 0.25s ease, box-shadow 0.25s ease;
        }
        .card-custom:hover {
            transform: translateY(-4px);
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.08);
        }

        /* Floating Virtual Assistant */
        .va-floating-btn {
            position: fixed;
            bottom: 24px;
            right: 24px;
            z-index: 1050;
            background: linear-gradient(135deg, var(--bs-primary), var(--bs-secondary));
            color: #fff;
            width: 62px;
            height: 62px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 8px 24px rgba(var(--bs-primary-rgb), 0.4);
            cursor: pointer;
            transition: all 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            border: 3px solid #ffffff;
        }
        .va-floating-btn:hover {
            transform: scale(1.1) rotate(5deg);
        }
        .va-pulse-dot {
            position: absolute;
            top: 2px;
            right: 2px;
            width: 14px;
            height: 14px;
            background-color: #22c55e;
            border: 2px solid #ffffff;
            border-radius: 50%;
            animation: pulse-ring 1.8s cubic-bezier(0.215, 0.61, 0.355, 1) infinite;
        }

        @keyframes pulse-ring {
            0% { transform: scale(0.95); box-shadow: 0 0 0 0 rgba(34, 197, 94, 0.7); }
            70% { transform: scale(1.1); box-shadow: 0 0 0 8px rgba(34, 197, 94, 0); }
            100% { transform: scale(0.95); box-shadow: 0 0 0 0 rgba(34, 197, 94, 0); }
        }

        .va-chat-box {
            position: fixed;
            bottom: 96px;
            right: 24px;
            width: 360px;
            max-width: calc(100vw - 48px);
            background: #ffffff;
            border-radius: 18px;
            box-shadow: 0 12px 36px rgba(0, 0, 0, 0.18);
            z-index: 1050;
            display: none;
            overflow: hidden;
            border: 1px solid #e2e8f0;
            animation: slideUp 0.3s ease;
        }

        @keyframes slideUp {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .va-chat-header {
            background: linear-gradient(135deg, var(--bs-primary), var(--bs-secondary));
            color: #fff;
            padding: 16px;
            position: relative;
        }

        .va-chat-body {
            height: 330px;
            overflow-y: auto;
            padding: 16px;
            background-color: #f8fafc;
            display: flex;
            flex-direction: column;
            gap: 12px;
        }

        .va-bubble-bot {
            background: #ffffff;
            color: #1e293b;
            padding: 10px 14px;
            border-radius: 14px 14px 14px 2px;
            box-shadow: 0 2px 6px rgba(0,0,0,0.05);
            font-size: 0.88rem;
            max-width: 85%;
            align-self: flex-start;
        }

        .va-bubble-user {
            background: var(--bs-primary);
            color: #ffffff;
            padding: 10px 14px;
            border-radius: 14px 14px 2px 14px;
            font-size: 0.88rem;
            max-width: 85%;
            align-self: flex-end;
        }

        .va-quick-option {
            background: #ffffff;
            border: 1px solid rgba(var(--bs-primary-rgb), 0.25);
            color: var(--bs-primary);
            padding: 7px 12px;
            border-radius: 20px;
            font-size: 0.82rem;
            font-weight: 600;
            text-align: left;
            cursor: pointer;
            transition: all 0.2s ease;
        }
        .va-quick-option:hover {
            background: var(--bs-primary);
            color: #ffffff;
        }
    </style>
    
    <!-- Design Tokens & Theme Presets (Industrialist vs Brutalist) -->
    <link rel="stylesheet" href="<?= base_url('assets/css/design-tokens.css') ?>?v=<?= file_exists(FCPATH . 'assets/css/design-tokens.css') ? filemtime(FCPATH . 'assets/css/design-tokens.css') : time() ?>">

    <?= $this->renderSection('styles') ?>
</head>
<body class="d-flex flex-column min-vh-100">

    <!-- Top Navbar -->
    <nav class="navbar navbar-expand-lg navbar-light bg-white sticky-top shadow-sm py-3">
        <div class="container">
            <a class="navbar-brand d-flex align-items-center gap-2" href="<?= site_url('/') ?>">
                <?php if (!empty($companyLogo) && file_exists(FCPATH . 'uploads/settings/' . $companyLogo)): ?>
                    <img src="<?= base_url('uploads/settings/' . esc($companyLogo)) ?>" alt="<?= esc($companyName) ?>" style="max-height: 44px; max-width: 140px; object-fit: contain;">
                <?php else: ?>
                    <i class="bi bi-buildings-fill fs-3 text-primary"></i>
                <?php endif; ?>
                <div>
                    <span class="fs-4 d-block lh-1"><?= esc($companyName) ?></span>
                    <small class="text-muted fw-normal fs-7" style="font-size: 0.75rem;"><?= esc($companyTagline) ?></small>
                </div>
            </a>
            <button class="navbar-toggler border-0" type="button" data-bs-toggle="collapse" data-bs-target="#navbarMain">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarMain">
                <ul class="navbar-nav ms-auto mb-2 mb-lg-0 align-items-lg-center gap-lg-3">
                    <li class="nav-item">
                        <a class="nav-link <?= uri_string() === '' ? 'active fw-bold text-primary' : '' ?>" href="<?= site_url('/') ?>">Beranda</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?= uri_string() === 'properti' ? 'active fw-bold text-primary' : '' ?>" href="<?= site_url('properti') ?>">Katalog Rumah</a>
                    </li>

                    <?php 
                    $navSiteplans = $activeSiteplans ?? (new \App\Models\SiteplanModel())->getActiveSiteplans();
                    $navSiteplanCount = count($navSiteplans);
                    ?>

                    <?php if ($navSiteplanCount === 1): ?>
                        <li class="nav-item">
                            <a class="nav-link <?= str_starts_with(uri_string(), 'siteplan') ? 'active fw-bold text-primary' : '' ?>" href="<?= site_url('siteplan/' . $navSiteplans[0]['id']) ?>">
                                <i class="bi bi-map-fill text-primary me-1"></i> Siteplan
                            </a>
                        </li>
                    <?php elseif ($navSiteplanCount > 1): ?>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle <?= str_starts_with(uri_string(), 'siteplan') ? 'active fw-bold text-primary' : '' ?>" href="#" id="navbarSiteplanDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                <i class="bi bi-map-fill text-primary me-1"></i> Siteplan
                                <span class="badge bg-primary text-white rounded-pill ms-1" style="font-size: 0.68rem; padding: 0.25em 0.55em;"><?= $navSiteplanCount ?></span>
                            </a>
                            <ul class="dropdown-menu dropdown-menu-end shadow-lg border-0 rounded-4 p-2 mt-2" aria-labelledby="navbarSiteplanDropdown" style="min-width: 260px;">
                                <li class="dropdown-header small fw-bold text-uppercase text-muted px-3 py-1" style="font-size: 0.72rem; letter-spacing: 0.5px;">Pilih Denah Siteplan (<?= $navSiteplanCount ?> Area)</li>
                                <li><hr class="dropdown-divider my-1"></li>
                                <?php foreach ($navSiteplans as $spNav): ?>
                                    <?php 
                                        $isCurNav = (isset($siteplan['id']) && $siteplan['id'] == $spNav['id']) || (uri_string() === 'siteplan/' . $spNav['id']);
                                    ?>
                                    <li>
                                        <a class="dropdown-item rounded-3 py-2 px-3 d-flex align-items-center gap-2 mb-1 <?= $isCurNav ? 'active bg-primary text-white' : '' ?>" href="<?= site_url('siteplan/' . $spNav['id']) ?>">
                                            <i class="bi bi-geo-alt-fill fs-6 <?= $isCurNav ? 'text-white' : 'text-primary' ?>"></i>
                                            <div class="flex-grow-1">
                                                <div class="fw-bold fs-7"><?= esc($spNav['title']) ?></div>
                                                <?php if (!empty($spNav['description'])): ?>
                                                    <div class="<?= $isCurNav ? 'text-white-50' : 'text-muted' ?>" style="font-size: 0.72rem;"><?= character_limiter(esc($spNav['description']), 30) ?></div>
                                                <?php endif; ?>
                                            </div>
                                        </a>
                                    </li>
                                <?php endforeach; ?>
                            </ul>
                        </li>
                    <?php else: ?>
                        <li class="nav-item">
                            <a class="nav-link <?= uri_string() === 'siteplan' ? 'active fw-bold text-primary' : '' ?>" href="<?= site_url('siteplan') ?>">
                                <i class="bi bi-map-fill text-primary me-1"></i> Siteplan
                            </a>
                        </li>
                    <?php endif; ?>

                    <li class="nav-item">
                        <a class="nav-link <?= uri_string() === 'kpr-calculator' ? 'active fw-bold text-primary' : '' ?>" href="<?= site_url('kpr-calculator') ?>">Simulasi KPR</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?= site_url('/#kontak') ?>">Kontak</a>
                    </li>
                    <!-- Live Theme Switcher Dropdown in Navbar -->
                    <li class="nav-item dropdown ms-lg-1">
                        <button class="btn btn-sm btn-outline-secondary dropdown-toggle d-flex align-items-center gap-1.5 px-3 py-2 rounded-pill" type="button" id="navbarThemeDropdown" data-bs-toggle="dropdown" aria-expanded="false" style="font-size: 0.82rem;">
                            <i class="bi bi-brush text-primary"></i> <span id="navbarThemeLabel">Tema</span>
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end shadow border-0 rounded-3 p-2 mt-2" aria-labelledby="navbarThemeDropdown" style="min-width: 230px;">
                            <li class="dropdown-header small fw-bold text-uppercase text-muted px-3 py-1" style="font-size: 0.7rem;">Pilih Tema Desain</li>
                            <li>
                                <a class="dropdown-item rounded-2 py-2 px-3 d-flex align-items-center gap-2 mb-1" href="javascript:void(0)" onclick="switchThemePreset('industrialist')">
                                    <i class="bi bi-gear-wide-connected text-warning fs-5"></i>
                                    <div>
                                        <div class="fw-bold" style="font-size: 0.84rem;">Industrialist Modern</div>
                                        <small class="text-muted" style="font-size: 0.7rem;">Dot-grid, copper accent, 10px</small>
                                    </div>
                                </a>
                            </li>
                            <li>
                                <a class="dropdown-item rounded-2 py-2 px-3 d-flex align-items-center gap-2" href="javascript:void(0)" onclick="switchThemePreset('brutalist')">
                                    <i class="bi bi-square-fill text-dark fs-5"></i>
                                    <div>
                                        <div class="fw-bold" style="font-size: 0.84rem;">Architectural Brutalist</div>
                                        <small class="text-muted" style="font-size: 0.7rem;">3px black border, hard shadow, 0px</small>
                                    </div>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class="nav-item ms-lg-2">
                        <a class="btn btn-primary px-3 py-2 rounded-pill d-flex align-items-center gap-2" href="https://wa.me/<?= esc($companyWa) ?>?text=Halo%20<?= urlencode($companyName) ?>,%20saya%20tertarik%20dengan%20properti%20Anda." target="_blank">
                            <i class="bi bi-whatsapp"></i> Hubungi Kami
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Main Content Area -->
    <main class="flex-grow-1">
        <!-- Flash Messages -->
        <?php if (session()->getFlashdata('success')): ?>
            <div class="container mt-3">
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <i class="bi bi-check-circle-fill me-2"></i> <?= session()->getFlashdata('success') ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            </div>
        <?php endif; ?>

        <?php if (session()->getFlashdata('error')): ?>
            <div class="container mt-3">
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <i class="bi bi-exclamation-triangle-fill me-2"></i> <?= session()->getFlashdata('error') ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            </div>
        <?php endif; ?>

        <?= $this->renderSection('content') ?>
    </main>

    <!-- Footer -->
    <footer id="kontak" class="bg-dark text-white pt-5 pb-4 mt-5">
        <div class="container">
            <div class="row g-4">
                <div class="col-lg-4">
                    <div class="d-flex align-items-center gap-2 mb-3">
                        <?php if (!empty($companyLogo) && file_exists(FCPATH . 'uploads/settings/' . $companyLogo)): ?>
                            <img src="<?= base_url('uploads/settings/' . esc($companyLogo)) ?>" alt="<?= esc($companyName) ?>" style="max-height: 40px; max-width: 120px; object-fit: contain;" class="bg-white p-1 rounded">
                        <?php else: ?>
                            <i class="bi bi-buildings-fill fs-3 text-white"></i>
                        <?php endif; ?>
                        <h4 class="fw-bold mb-0 text-white"><?= esc($companyName) ?></h4>
                    </div>
                    <p class="text-secondary mb-3"><?= esc($settings['company_about'] ?? 'Hunian asri dan modern dengan fasilitas lengkap terintegrasi serta akses transportasi strategis.') ?></p>
                    <div class="d-flex gap-3">
                        <a href="https://wa.me/<?= esc($companyWa) ?>" target="_blank" class="text-white fs-5"><i class="bi bi-whatsapp"></i></a>
                        <a href="mailto:<?= esc($companyEmail) ?>" class="text-white fs-5"><i class="bi bi-envelope"></i></a>
                        <a href="#" class="text-white fs-5"><i class="bi bi-instagram"></i></a>
                        <a href="#" class="text-white fs-5"><i class="bi bi-facebook"></i></a>
                    </div>
                </div>
                <div class="col-lg-4">
                    <h5 class="fw-bold mb-3 text-white">Navigasi Cepat</h5>
                    <ul class="list-unstyled text-secondary d-flex flex-column gap-2">
                        <li><a href="<?= site_url('/') ?>" class="text-secondary text-decoration-none hover-white">Beranda</a></li>
                        <li><a href="<?= site_url('properti') ?>" class="text-secondary text-decoration-none hover-white">Katalog Properti</a></li>
                        <li><a href="<?= site_url('kpr-calculator') ?>" class="text-secondary text-decoration-none hover-white">Kalkulator KPR</a></li>
                        <li><a href="<?= site_url('brochure/download-global') ?>" class="text-secondary text-decoration-none hover-white">E-Brochure Digital</a></li>
                        <li><a href="<?= site_url('admin/login') ?>" class="text-secondary text-decoration-none hover-white"><i class="bi bi-lock-fill me-1"></i> Admin Portal</a></li>
                    </ul>
                </div>
                <div class="col-lg-4">
                    <h5 class="fw-bold mb-3 text-white">Kantor Pemasaran</h5>
                    <ul class="list-unstyled text-secondary d-flex flex-column gap-2">
                        <li class="d-flex gap-2">
                            <i class="bi bi-geo-alt-fill text-primary"></i>
                            <span><?= esc($companyAddress) ?></span>
                        </li>
                        <li class="d-flex gap-2">
                            <i class="bi bi-telephone-fill text-primary"></i>
                            <span><?= esc($companyPhone) ?></span>
                        </li>
                        <li class="d-flex gap-2">
                            <i class="bi bi-whatsapp text-primary"></i>
                            <span>+<?= esc($companyWa) ?></span>
                        </li>
                        <li class="d-flex gap-2">
                            <i class="bi bi-envelope-fill text-primary"></i>
                            <span><?= esc($companyEmail) ?></span>
                        </li>
                    </ul>
                </div>
            </div>
            <hr class="border-secondary my-4">
            <div class="d-flex flex-column flex-sm-row justify-content-between align-items-center text-secondary small">
                <p class="mb-0">&copy; <?= date('Y') ?> <?= esc($companyName) ?>. All rights reserved.</p>
                <p class="mb-0">Designed for Seamless Property Experience.</p>
            </div>
        </div>
    </footer>

    <!-- PROMO POP-UP MODAL (Dynamic from Settings & jQuery sessionStorage) -->
    <?php if (($settings['promo_modal_active'] ?? '0') === '1'): ?>
        <div class="modal fade" id="promoModal" tabindex="-1" aria-labelledby="promoModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered modal-lg">
                <div class="modal-content overflow-hidden border-0 shadow-lg" style="border-radius: 18px;">
                    <div class="modal-body p-0 position-relative">
                        <button type="button" class="btn-close position-absolute top-0 end-0 m-3 z-3 bg-white p-2 rounded-circle shadow-sm" data-bs-dismiss="modal" aria-label="Close" id="btnClosePromo"></button>
                        <div class="row g-0">
                            <div class="col-md-6">
                                <?php 
                                $promoImg = $settings['promo_modal_image'] ?? '';
                                if (empty($promoImg)) {
                                    $promoImg = 'https://images.unsplash.com/photo-1580587771525-78b9dba3b914?w=800&auto=format&fit=crop&q=60';
                                }
                                ?>
                                <img src="<?= esc($promoImg) ?>" alt="Promo Spesial" class="w-100 h-100 object-fit-cover" style="min-height: 280px; max-height: 380px;">
                            </div>
                            <div class="col-md-6 p-4 d-flex flex-column justify-content-center">
                                <span class="badge bg-danger align-self-start mb-2 px-3 py-1 rounded-pill">PENERIMA TERBATAS</span>
                                <h4 class="fw-bold text-dark mb-2" id="promoModalLabel"><?= esc($settings['promo_modal_title'] ?? 'Promo Spesial Bulan Ini!') ?></h4>
                                <p class="text-muted small mb-4"><?= nl2br(esc($settings['promo_modal_desc'] ?? 'Dapatkan diskon DP dan bunga subsidi khusus untuk pendaftaran hari ini.')) ?></p>
                                <div class="d-grid gap-2">
                                    <a href="https://wa.me/<?= esc($companyWa) ?>?text=Halo%20<?= urlencode($companyName) ?>,%20saya%20ingin%20mengklaim%20promo%20spesial%20<?= urlencode($settings['promo_modal_title'] ?? '') ?>" target="_blank" class="btn btn-primary py-2 rounded-pill d-flex align-items-center justify-content-center gap-2">
                                        <i class="bi bi-whatsapp"></i> <?= esc($settings['promo_modal_btn_text'] ?? 'Klaim Promo via WhatsApp') ?>
                                    </a>
                                    <button type="button" class="btn btn-light py-2 rounded-pill text-muted" data-bs-dismiss="modal">Nanti Saja</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>

    <!-- UNIT PROMO POP-UP MODAL (Interactive for Checked Promo Properties) -->
    <div class="modal fade" id="unitPromoModal" tabindex="-1" aria-labelledby="unitPromoModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content overflow-hidden border-0 shadow-lg" style="border-radius: 20px;">
                <div class="modal-body p-0 position-relative">
                    <button type="button" class="btn-close position-absolute top-0 end-0 m-3 z-3 bg-white p-2 rounded-circle shadow-sm" data-bs-dismiss="modal" aria-label="Close"></button>
                    <div class="row g-0">
                        <div class="col-md-5 position-relative bg-light">
                            <img src="" id="modalPromoUnitImg" alt="Unit Promo" class="w-100 h-100 object-fit-cover" style="min-height: 280px; max-height: 400px;">
                            <span class="position-absolute top-0 start-0 m-3 badge bg-danger text-white rounded-pill px-3 py-2 shadow-sm">
                                <i class="bi bi-fire text-warning me-1"></i> PROMO SPESIAL
                            </span>
                        </div>
                        <div class="col-md-7 p-4 d-flex flex-column justify-content-between">
                            <div>
                                <div class="d-flex align-items-center justify-content-between mb-1">
                                    <span class="badge bg-warning text-dark px-2 py-1 rounded-pill small fw-bold shadow-sm">
                                        <i class="bi bi-tag-fill me-1 text-danger"></i> Penawaran Eksklusif
                                    </span>
                                    <span class="fw-extrabold text-primary fs-5" id="modalPromoUnitPrice"></span>
                                </div>
                                <h4 class="fw-bold text-dark mb-1" id="modalPromoUnitTitle"></h4>
                                <h6 class="fw-bold text-danger mb-3" id="modalPromoTitleText"></h6>
                                
                                <div class="bg-light p-3 rounded-3 mb-3 border">
                                    <h6 class="small fw-bold text-dark mb-2"><i class="bi bi-gift-fill text-danger me-1"></i> Keuntungan & Bonus Promo:</h6>
                                    <div class="text-muted small" id="modalPromoDescText" style="line-height: 1.6;"></div>
                                </div>
                            </div>

                            <div class="d-flex flex-column gap-2 mt-2">
                                <a href="#" target="_blank" class="btn btn-success py-2 rounded-pill fw-bold d-flex align-items-center justify-content-center gap-2 shadow-sm" id="btnClaimUnitPromoWa">
                                    <i class="bi bi-whatsapp fs-5"></i> Klaim Promo Unit Ini via WhatsApp
                                </a>
                                <div class="d-flex gap-2">
                                    <a href="#" class="btn btn-outline-primary btn-sm py-2 rounded-pill flex-grow-1" id="btnViewUnitDetail">
                                        <i class="bi bi-house-door me-1"></i> Lihat Spesifikasi Rumah
                                    </a>
                                    <button type="button" class="btn btn-light btn-sm py-2 rounded-pill px-3 text-muted" data-bs-dismiss="modal">Tutup</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- VIRTUAL ASSISTANT FLOATING CHAT WIDGET -->
    <div class="va-floating-btn" id="btnToggleVA" title="Chat dengan <?= esc($vaName) ?>">
        <div class="va-pulse-dot"></div>
        <i class="bi bi-chat-dots-fill fs-4"></i>
    </div>

    <div class="va-chat-box" id="vaChatBox">
        <div class="va-chat-header d-flex justify-content-between align-items-center">
            <div class="d-flex align-items-center gap-2">
                <div class="bg-white text-primary rounded-circle d-flex align-items-center justify-content-center shadow-sm" style="width: 38px; height: 38px;">
                    <i class="bi bi-robot fs-5"></i>
                </div>
                <div>
                    <h6 class="mb-0 fw-bold text-white fs-6"><?= esc($vaName) ?></h6>
                    <small class="text-white-50 fs-7" style="font-size: 0.72rem;"><i class="bi bi-circle-fill text-success" style="font-size: 0.55rem;"></i> Online | Siap Menjawab</small>
                </div>
            </div>
            <div class="d-flex align-items-center gap-1">
                <span class="badge bg-white text-primary border px-2 py-1 rounded-pill shadow-sm" id="vaUserHeaderBadge" style="display: none; font-size: 0.7rem;">
                    <i class="bi bi-person-fill me-1"></i><span id="vaUserHeaderName"></span>
                </span>
                <button type="button" class="btn btn-sm text-white-50 p-1" id="vaResetChat" title="Reset Percakapan"><i class="bi bi-arrow-counterclockwise fs-6"></i></button>
                <button type="button" class="btn-close btn-close-white ms-1" id="btnCloseVA"></button>
            </div>
        </div>

        <!-- Chat Conversation Messages Body -->
        <div class="va-chat-body" id="vaChatBody">
            <!-- Dynamic Content initialized by JavaScript -->
        </div>

        <!-- Interactive Typing Input Area -->
        <div class="p-2 bg-white border-top">
            <form id="vaChatForm" class="d-flex gap-2 align-items-center">
                <input type="text" id="vaUserInput" class="form-control form-control-sm rounded-pill px-3" placeholder="Ketik pertanyaan Anda di sini..." autocomplete="off" required>
                <button type="submit" class="btn btn-primary btn-sm rounded-circle d-flex align-items-center justify-content-center flex-shrink-0" style="width: 36px; height: 36px;" title="Kirim Pesan">
                    <i class="bi bi-send-fill" style="font-size: 0.85rem;"></i>
                </button>
            </form>
        </div>
    </div>

    <!-- Scripts -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

    <script>
        $(document).ready(function() {
            // ==========================================
            // 1. PROMO POP-UP WITH sessionStorage
            // ==========================================
            var promoActive = "<?= $settings['promo_modal_active'] ?? '0' ?>";
            var promoClosed = sessionStorage.getItem('promo_closed_session');

            if (promoActive === '1' && !promoClosed) {
                setTimeout(function() {
                    var promoModalEl = document.getElementById('promoModal');
                    if (promoModalEl) {
                        var promoModal = new bootstrap.Modal(promoModalEl);
                        promoModal.show();
                    }
                }, 1200);
            }

            $('#promoModal').on('hidden.bs.modal', function () {
                sessionStorage.setItem('promo_closed_session', 'true');
            });

            // ==========================================
            // 2. UNIT-SPECIFIC PROMO POP-UP MODAL HANDLER
            // ==========================================
            $(document).on('click', '.btn-unit-promo-trigger', function(e) {
                e.preventDefault();
                var title = $(this).data('title') || '';
                var price = $(this).data('price') || '';
                var promoTitle = $(this).data('promo-title') || 'Promo Spesial Unit';
                var promoDesc = $(this).data('promo-desc') || 'Dapatkan potongan harga, subsidi DP/KPR, dan promo menarik khusus unit ini.';
                var slug = $(this).data('slug') || '';
                var img = $(this).data('img') || '';

                $('#modalPromoUnitTitle').text(title);
                $('#modalPromoUnitPrice').text(price);
                $('#modalPromoTitleText').text(promoTitle);

                // Format bullet perks for promo description
                var descLines = promoDesc ? promoDesc.split('\n') : ['Promo eksklusif terbatas untuk unit ini.'];
                var descHtml = '';
                $.each(descLines, function(i, line) {
                    if (line.trim()) {
                        descHtml += '<div class="d-flex align-items-start gap-2 mb-1.5"><i class="bi bi-check-circle-fill text-success flex-shrink-0 mt-1" style="font-size: 0.85rem;"></i><span>' + $('<div>').text(line.trim()).html() + '</span></div>';
                    }
                });
                $('#modalPromoDescText').html(descHtml);
                $('#modalPromoUnitImg').attr('src', img);
                $('#btnViewUnitDetail').attr('href', "<?= site_url('properti') ?>/" + slug);

                var userLead = getUserLead();
                var userGreeting = (userLead && userLead.nama) ? ('Halo <?= esc($companyName) ?>, saya ' + userLead.nama + ', saya tertarik dan ingin klaim promo untuk ' + title + ' (' + promoTitle + '). Mohon info selengkapnya ya.') : ('Halo <?= esc($companyName) ?>, saya tertarik dan ingin klaim promo untuk ' + title + ' (' + promoTitle + '). Mohon info selengkapnya ya.');
                var waUrl = 'https://wa.me/<?= esc($companyWa) ?>?text=' + encodeURIComponent(userGreeting);
                $('#btnClaimUnitPromoWa').attr('href', waUrl);

                var unitModalEl = document.getElementById('unitPromoModal');
                if (unitModalEl) {
                    var modal = new bootstrap.Modal(unitModalEl);
                    modal.show();
                }
            });

            // ==========================================
            // 3. VIRTUAL ASSISTANT FULL INTERACTIVE CONVERSATION & PRE-CHAT LEAD FORM
            // ==========================================
            var vaPhone = "<?= esc($vaPhone) ?>";
            var compName = "<?= esc($companyName) ?>";
            var compAddress = "<?= esc($companyAddress) ?>";
            var vaName = "<?= esc($vaName) ?>";
            var chatHistory = [];

            function escapeHtml(text) {
                if (!text) return '';
                return text
                    .replace(/&/g, '&amp;')
                    .replace(/</g, '&lt;')
                    .replace(/>/g, '&gt;')
                    .replace(/"/g, '&quot;')
                    .replace(/'/g, '&#039;');
            }

            function getUserLead() {
                try {
                    return JSON.parse(localStorage.getItem('va_user_lead') || '{}');
                } catch (e) {
                    return {};
                }
            }

            function updateHeaderUserBadge() {
                var userLead = getUserLead();
                if (userLead.nama && userLead.submitted) {
                    $('#vaUserHeaderName').text(userLead.nama);
                    $('#vaUserHeaderBadge').fadeIn(200);
                } else {
                    $('#vaUserHeaderBadge').hide();
                }
            }

            function initChatBody() {
                var userLead = getUserLead();
                updateHeaderUserBadge();

                // If lead data already exists (either filled or skipped), show standard personalized greeting without form
                if (userLead.submitted || userLead.skipped) {
                    var greetingName = userLead.nama ? ('Kak <strong>' + escapeHtml(userLead.nama) + '</strong>') : '';
                    var welcomeHtml = '<div class="va-bubble-bot shadow-sm">' +
                        'Halo ' + (greetingName ? greetingName + '! ' : '') + 'Selamat datang di <strong>' + compName + '</strong>. 👋<br><br>' +
                        'Saya <strong>' + vaName + '</strong>, konsultan properti resmi. Ada yang bisa saya bantu? Anda bisa mengetik pertanyaan langsung di bawah atau memilih topik cepat:' +
                    '</div>' +
                    '<div class="d-flex flex-wrap gap-1 mt-1" id="vaOptionsContainer">' +
                        '<button class="va-quick-option" data-option="katalog"><i class="bi bi-house-door me-1"></i> Tipe & Harga Rumah</button>' +
                        '<button class="va-quick-option" data-option="siteplan"><i class="bi bi-map-fill me-1"></i> Denah Siteplan</button>' +
                        '<button class="va-quick-option" data-option="kpr"><i class="bi bi-calculator me-1"></i> Simulasi & Syarat KPR</button>' +
                        '<button class="va-quick-option" data-option="promo"><i class="bi bi-tag-fill me-1"></i> Promo & Diskon DP</button>' +
                        '<button class="va-quick-option" data-option="survey"><i class="bi bi-calendar2-check me-1"></i> Jadwal Survey Lokasi</button>' +
                        '<button class="va-quick-option" data-option="legalitas"><i class="bi bi-shield-check me-1"></i> Legalitas & SHM</button>' +
                        '<button class="va-quick-option" data-option="lokasi"><i class="bi bi-geo-alt me-1"></i> Alamat & Akses</button>' +
                    '</div>';
                    $('#vaChatBody').html(welcomeHtml);
                } else {
                    // First time opening: Show interactive 1-time Pre-Chat Lead Capture Form
                    var formHtml = '<div class="va-bubble-bot shadow-sm">' +
                        'Halo! Selamat datang di <strong>' + compName + '</strong>. 👋' +
                        '<div class="mt-2 text-dark" style="font-size: 0.82rem;">' +
                            'Agar kami dapat memberikan rekomendasi tipe hunian, e-brosur, dan promo KPR yang tepat untuk Anda, mohon isi data singkat berikut:' +
                        '</div>' +
                        '<div class="card border-0 bg-white shadow-sm p-3 mt-2 rounded-3 text-start" id="vaLeadFormCard">' +
                            '<form id="vaLeadForm">' +
                                '<div class="mb-2">' +
                                    '<label class="form-label small fw-bold text-muted mb-1" style="font-size: 0.72rem;"><i class="bi bi-person-fill text-primary me-1"></i>Nama Lengkap</label>' +
                                    '<input type="text" id="vaLeadName" class="form-control form-control-sm rounded-pill px-3" placeholder="Contoh: Budi Santoso" required>' +
                                '</div>' +
                                '<div class="mb-2">' +
                                    '<label class="form-label small fw-bold text-muted mb-1" style="font-size: 0.72rem;"><i class="bi bi-whatsapp text-success me-1"></i>Nomor WhatsApp Aktif</label>' +
                                    '<input type="tel" id="vaLeadPhone" class="form-control form-control-sm rounded-pill px-3" placeholder="Contoh: 081234567890" required>' +
                                '</div>' +
                                '<div class="d-grid gap-1 mt-3">' +
                                    '<button type="submit" class="btn btn-primary btn-sm rounded-pill fw-bold py-1 shadow-sm" id="btnSubmitLead">' +
                                        '<i class="bi bi-send-check-fill me-1"></i> Mulai Konsultasi' +
                                    '</button>' +
                                    '<button type="button" class="btn btn-link btn-sm text-muted text-decoration-none py-0 mt-1" id="btnSkipLead" style="font-size: 0.72rem;">' +
                                        'Lewati & Langsung Chat' +
                                    '</button>' +
                                '</div>' +
                            '</form>' +
                        '</div>' +
                    '</div>';
                    $('#vaChatBody').html(formHtml);
                }
            }

            initChatBody();

            $('#btnToggleVA').on('click', function() {
                $('#vaChatBox').fadeToggle(200);
                if ($('#vaChatBox').is(':visible')) {
                    if ($('#vaLeadName').length) {
                        $('#vaLeadName').focus();
                    } else {
                        $('#vaUserInput').focus();
                    }
                }
            });

            $('#btnCloseVA').on('click', function() {
                $('#vaChatBox').fadeOut(200);
            });

            function scrollChatToBottom() {
                var body = $('#vaChatBody');
                body.animate({ scrollTop: body[0].scrollHeight }, 300);
            }

            function appendBotTypingIndicator() {
                var typingId = 'typing_' + Date.now();
                var html = '<div class="va-bubble-bot d-flex align-items-center gap-1 py-2 px-3" id="' + typingId + '">' +
                    '<span class="spinner-grow spinner-grow-sm text-primary" style="width: 8px; height: 8px;"></span>' +
                    '<span class="spinner-grow spinner-grow-sm text-primary" style="width: 8px; height: 8px; animation-delay: 0.15s;"></span>' +
                    '<span class="spinner-grow spinner-grow-sm text-primary" style="width: 8px; height: 8px; animation-delay: 0.3s;"></span>' +
                    '<small class="text-muted ms-1" style="font-size: 0.75rem;">' + compName + ' sedang mengetik...</small>' +
                '</div>';
                $('#vaChatBody').append(html);
                scrollChatToBottom();
                return typingId;
            }

            function appendUserBubble(text) {
                var userLead = getUserLead();
                var displayName = (userLead && userLead.nama) ? escapeHtml(userLead.nama) : 'Anda';
                var bubbleHtml = '<div class="va-bubble-user shadow-sm">' +
                    '<div class="d-flex align-items-center justify-content-end gap-1 mb-1 text-white-50" style="font-size: 0.68rem; font-weight: 600;">' +
                        '<i class="bi bi-person-circle"></i> <span>' + displayName + '</span>' +
                    '</div>' +
                    '<div>' + escapeHtml(text) + '</div>' +
                '</div>';
                $('#vaChatBody').append(bubbleHtml);
                scrollChatToBottom();
            }

            // Enhanced Markdown parser for rich real estate conversation formatting
            function parseMarkdown(text) {
                if (!text) return '';
                var escaped = text
                    .replace(/&/g, '&amp;')
                    .replace(/</g, '&lt;')
                    .replace(/>/g, '&gt;');

                // Bold **text** or __text__
                escaped = escaped.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
                escaped = escaped.replace(/__(.*?)__/g, '<strong>$1</strong>');

                // Italic *text*
                escaped = escaped.replace(/\*([^\*\n]+)\*/g, '<em>$1</em>');

                // Numbered lists 1. Item
                escaped = escaped.replace(/^(\d+)\.\s+(.+)$/gm, '<div class="ms-1 mb-1"><strong>$1.</strong> $2</div>');

                // Bullet points • or - or *
                escaped = escaped.replace(/^[•\-\*]\s+(.+)$/gm, '<div class="ms-1 mb-1">▪ $1</div>');

                // Double linebreaks to space
                escaped = escaped.replace(/\n\n/g, '<div class="my-2"></div>');
                escaped = escaped.replace(/\n/g, '<br>');

                return escaped;
            }

            // Handle Lead Form Submission (1-Time)
            $(document).on('submit', '#vaLeadForm', function(e) {
                e.preventDefault();
                var name = $('#vaLeadName').val().trim();
                var phone = $('#vaLeadPhone').val().trim();
                if (!name || !phone) return;

                var btn = $('#btnSubmitLead');
                btn.prop('disabled', true).html('<span class="spinner-border spinner-border-sm me-1"></span> Menyimpan...');

                // Store Lead into backend database
                $.ajax({
                    url: "<?= site_url('leads/store') ?>",
                    type: "POST",
                    data: {
                        nama_prospek: name,
                        no_wa: phone,
                        "<?= csrf_token() ?>": "<?= csrf_hash() ?>"
                    },
                    dataType: "json",
                    complete: function() {
                        // Persist in localStorage so it never shows again
                        localStorage.setItem('va_user_lead', JSON.stringify({
                            nama: name,
                            phone: phone,
                            submitted: true
                        }));

                        updateHeaderUserBadge();
                        $('#vaLeadFormCard').parent().remove();

                        var successHtml = '<div class="va-bubble-bot shadow-sm">' +
                            'Terima kasih Kak <strong>' + escapeHtml(name) + '</strong>! Data Anda telah tersimpan dengan aman. 🙏<br><br>' +
                            'Saya <strong>' + vaName + '</strong> siap membantu mendampingi Anda menemukan hunian terbaik di <strong>' + compName + '</strong>. Silakan pilih topik cepat di bawah atau ketik pertanyaan langsung:' +
                        '</div>' +
                        '<div class="d-flex flex-wrap gap-1 mt-1" id="vaOptionsContainer">' +
                            '<button class="va-quick-option" data-option="katalog"><i class="bi bi-house-door me-1"></i> Tipe & Harga Rumah</button>' +
                            '<button class="va-quick-option" data-option="kpr"><i class="bi bi-calculator me-1"></i> Simulasi & Syarat KPR</button>' +
                            '<button class="va-quick-option" data-option="promo"><i class="bi bi-tag-fill me-1"></i> Promo & Diskon DP</button>' +
                            '<button class="va-quick-option" data-option="survey"><i class="bi bi-calendar2-check me-1"></i> Jadwal Survey Lokasi</button>' +
                            '<button class="va-quick-option" data-option="legalitas"><i class="bi bi-shield-check me-1"></i> Legalitas & SHM</button>' +
                            '<button class="va-quick-option" data-option="lokasi"><i class="bi bi-geo-alt me-1"></i> Alamat & Akses</button>' +
                        '</div>';

                        $('#vaChatBody').append(successHtml);
                        scrollChatToBottom();
                        $('#vaUserInput').focus();
                    }
                });
            });

            // Handle Skip Lead Form
            $(document).on('click', '#btnSkipLead', function() {
                localStorage.setItem('va_user_lead', JSON.stringify({
                    skipped: true
                }));

                $('#vaLeadFormCard').parent().remove();

                var skipHtml = '<div class="va-bubble-bot shadow-sm">' +
                    'Halo! Saya <strong>' + vaName + '</strong> dari <strong>' + compName + '</strong>. 👋<br><br>' +
                    'Ada yang bisa saya bantu hari ini? Anda bisa mengetik pertanyaan langsung di bawah atau memilih topik cepat berikut:' +
                '</div>' +
                '<div class="d-flex flex-wrap gap-1 mt-1" id="vaOptionsContainer">' +
                    '<button class="va-quick-option" data-option="katalog"><i class="bi bi-house-door me-1"></i> Tipe & Harga Rumah</button>' +
                    '<button class="va-quick-option" data-option="kpr"><i class="bi bi-calculator me-1"></i> Simulasi & Syarat KPR</button>' +
                    '<button class="va-quick-option" data-option="promo"><i class="bi bi-tag-fill me-1"></i> Promo & Diskon DP</button>' +
                    '<button class="va-quick-option" data-option="survey"><i class="bi bi-calendar2-check me-1"></i> Jadwal Survey Lokasi</button>' +
                    '<button class="va-quick-option" data-option="legalitas"><i class="bi bi-shield-check me-1"></i> Legalitas & SHM</button>' +
                    '<button class="va-quick-option" data-option="lokasi"><i class="bi bi-geo-alt me-1"></i> Alamat & Akses</button>' +
                '</div>';

                $('#vaChatBody').append(skipHtml);
                scrollChatToBottom();
                $('#vaUserInput').focus();
            });

            // Intelligent Conversational Response Logic via Gemini AI Backend
            function processUserMessage(rawText) {
                var typingId = appendBotTypingIndicator();
                var userLead = getUserLead();

                $.ajax({
                    url: "<?= site_url('api/chat/send') ?>",
                    type: "POST",
                    data: {
                        message: rawText,
                        user_name: userLead.nama || '',
                        history: JSON.stringify(chatHistory),
                        "<?= csrf_token() ?>": "<?= csrf_hash() ?>"
                    },
                    dataType: "json",
                    success: function(res) {
                        $('#' + typingId).remove();

                        var replyText = res.reply || 'Terima kasih atas pertanyaan Anda.';
                        var formattedText = parseMarkdown(replyText);
                        var waGreetingText = userLead.nama ? ('Halo ' + compName + ', saya ' + userLead.nama + ', ' + rawText) : ('Halo ' + compName + ', ' + rawText);
                        var directWaUrl = res.wa_url || ('https://wa.me/' + vaPhone + '?text=' + encodeURIComponent(waGreetingText));

                        // Store in history for multi-turn conversational context
                        chatHistory.push({ role: 'user', text: rawText });
                        chatHistory.push({ role: 'model', text: replyText });
                        if (chatHistory.length > 10) {
                            chatHistory = chatHistory.slice(-10);
                        }

                        var actionButtons = '<div class="mt-2 d-flex flex-wrap gap-2">' +
                            '<a href="' + directWaUrl + '" target="_blank" class="btn btn-success btn-sm rounded-pill px-3 py-1 fw-bold shadow-sm"><i class="bi bi-whatsapp me-1"></i> Konsultasi WhatsApp</a>' +
                            '<a href="<?= site_url('properti') ?>" class="btn btn-outline-primary btn-sm rounded-pill px-3 py-1 fw-semibold"><i class="bi bi-houses me-1"></i> Katalog Properti</a>' +
                        '</div>';

                        var badgeSource = '';
                        if (res.source === 'n8n') {
                            badgeSource = '<div class="d-block text-end mt-1"><small class="badge bg-danger-soft text-danger" style="font-size: 0.65rem;"><i class="bi bi-diagram-3-fill me-1"></i> n8n AI Assistant</small></div>';
                        }

                        var html = '<div class="va-bubble-bot shadow-sm">' + formattedText + badgeSource + actionButtons + '</div>';
                        $('#vaChatBody').append(html);
                        scrollChatToBottom();
                    },
                    error: function() {
                        $('#' + typingId).remove();
                        var waGreetingText = userLead.nama ? ('Halo ' + compName + ', saya ' + userLead.nama + ', ' + rawText) : ('Halo ' + compName + ', ' + rawText);
                        var fallbackWa = 'https://wa.me/' + vaPhone + '?text=' + encodeURIComponent(waGreetingText);
                        var html = '<div class="va-bubble-bot shadow-sm">' +
                            'Halo! Mohon maaf jaringan sedang sibuk. Anda dapat langsung berkonsultasi dengan konsultan pemasaran kami melalui WhatsApp di bawah ini:' +
                            '<div class="mt-2">' +
                                '<a href="' + fallbackWa + '" target="_blank" class="btn btn-success btn-sm rounded-pill px-3 py-1 fw-bold"><i class="bi bi-whatsapp me-1"></i> Hubungi WhatsApp Marketing</a>' +
                            '</div>' +
                        '</div>';
                        $('#vaChatBody').append(html);
                        scrollChatToBottom();
                    }
                });
            }

            // Handle Free Text Form Submit
            $('#vaChatForm').on('submit', function(e) {
                e.preventDefault();
                var msg = $('#vaUserInput').val().trim();
                if (!msg) return;

                // If lead form card is still visible when typing directly, dismiss it
                if ($('#vaLeadFormCard').length) {
                    var userLead = getUserLead();
                    if (!userLead.submitted) {
                        localStorage.setItem('va_user_lead', JSON.stringify({ skipped: true }));
                        $('#vaLeadFormCard').parent().remove();
                    }
                }

                // Append user bubble with visitor's name
                appendUserBubble(msg);
                $('#vaUserInput').val('');

                // Process bot response
                processUserMessage(msg);
            });

            // Handle Quick Options
            $(document).on('click', '.va-quick-option', function() {
                var text = $(this).text().trim();

                appendUserBubble(text);
                processUserMessage(text);
            });

            // Reset Chat
            $('#vaResetChat').on('click', function() {
                chatHistory = [];
                initChatBody();
                $('#vaUserInput').focus();
            });
        });
    </script>

    <!-- Floating Live Theme Preview Switcher (Always accessible on live website) -->
    <div class="live-theme-switcher-bar" id="liveThemeSwitcher" title="Ganti Gaya Desain Web Secara Instan">
        <span class="live-theme-switcher-label">
            <i class="bi bi-palette2 text-primary"></i> Tema:
        </span>
        <button type="button" class="theme-preset-btn" data-theme="industrialist" onclick="switchThemePreset('industrialist')">
            <i class="bi bi-gear-wide-connected text-warning"></i> Industrialist
        </button>
        <button type="button" class="theme-preset-btn" data-theme="brutalist" onclick="switchThemePreset('brutalist')">
            <i class="bi bi-square-fill text-dark"></i> Brutalist
        </button>
    </div>

    <!-- Quick Toast Notification on Theme Switch -->
    <div id="themeSwitchToast" style="position: fixed; bottom: 80px; left: 24px; z-index: 1070; background: #0f172a; color: #ffffff; padding: 8px 16px; border-radius: 9999px; font-size: 0.8rem; font-weight: 700; box-shadow: 0 8px 24px rgba(0,0,0,0.25); display: none; align-items: center; gap: 8px;">
        <span id="themeToastIcon">🎨</span>
        <span id="themeToastMsg">Tema berhasil diubah</span>
    </div>

    <script>
        // =========================================================================
        // 4. LIVE THEME PRESET SWITCHER (Industrialist vs Brutalist)
        // =========================================================================
        function applyThemePreset(theme) {
            if (!theme || (theme !== 'industrialist' && theme !== 'brutalist')) {
                theme = 'industrialist';
            }
            
            document.documentElement.setAttribute('data-theme-preset', theme);
            if (document.body) {
                document.body.setAttribute('data-theme-preset', theme);
            }
            localStorage.setItem('site_theme_preset_preview', theme);

            // Update floating switcher buttons
            document.querySelectorAll('.theme-preset-btn').forEach(function(btn) {
                if (btn.getAttribute('data-theme') === theme) {
                    btn.classList.add('active');
                } else {
                    btn.classList.remove('active');
                }
            });

            // Update navbar label
            const labelEl = document.getElementById('navbarThemeLabel');
            if (labelEl) {
                labelEl.textContent = theme === 'brutalist' ? 'Brutalist' : 'Industrialist';
            }
        }

        function switchThemePreset(theme) {
            applyThemePreset(theme);
            
            // Show toast feedback
            const toastEl = document.getElementById('themeSwitchToast');
            const iconEl = document.getElementById('themeToastIcon');
            const msgEl = document.getElementById('themeToastMsg');
            if (toastEl && msgEl) {
                if (theme === 'brutalist') {
                    iconEl.textContent = '🏛️';
                    msgEl.textContent = 'Tema: Architectural Brutalist Aktif';
                    toastEl.style.background = '#000000';
                    toastEl.style.border = '2px solid #ff3d00';
                } else {
                    iconEl.textContent = '🏗️';
                    msgEl.textContent = 'Tema: Industrialist Modern Aktif';
                    toastEl.style.background = '#b45309';
                    toastEl.style.border = '2px solid #f59e0b';
                }
                toastEl.style.display = 'flex';
                clearTimeout(window._themeToastTimer);
                window._themeToastTimer = setTimeout(function() {
                    toastEl.style.display = 'none';
                }, 2200);
            }
        }

        // Initialize theme preset on load (query parameter ?theme= > localStorage > database default)
        document.addEventListener('DOMContentLoaded', function() {
            try {
                const urlParams = new URLSearchParams(window.location.search);
                const queryTheme = urlParams.get('theme');
                const savedTheme = localStorage.getItem('site_theme_preset_preview');
                const defaultTheme = "<?= esc($siteThemePreset) ?>" || 'industrialist';
                
                const activeTheme = queryTheme || savedTheme || defaultTheme;
                applyThemePreset(activeTheme);
            } catch(e) {
                console.error('Theme init error:', e);
            }
        });
    </script>

    <?= $this->renderSection('scripts') ?>
</body>
</html>
