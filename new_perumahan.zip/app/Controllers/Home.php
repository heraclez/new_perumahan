<?php

namespace App\Controllers;

use App\Models\PropertyModel;

class Home extends BaseController
{
    public function index(): string
    {
        $propertyModel = new PropertyModel();
        
        $featuredProperties = [];
        try {
            $featuredProperties = $propertyModel->getPropertiesWithThumbnail([], 6);
        } catch (\Throwable $e) {
            log_message('notice', 'Using fallback property data: ' . $e->getMessage());
            $featuredProperties = [
                [
                    'id'          => 1,
                    'title'       => 'The Lumina Sanctuary',
                    'slug'        => 'the-lumina-sanctuary',
                    'cluster_name'=> 'Nordic Forest',
                    'price'       => 1850000000,
                    'surface_area'=> 120,
                    'building_area'=> 145,
                    'bedrooms'    => 4,
                    'bathrooms'   => 3,
                    'image_path'  => 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1200&q=80',
                    'tagline'     => 'Minimalist Modern Haven'
                ],
                [
                    'id'          => 2,
                    'title'       => 'The Horizon Villa',
                    'slug'        => 'the-horizon-villa',
                    'cluster_name'=> 'Zenith Garden',
                    'price'       => 2450000000,
                    'surface_area'=> 160,
                    'building_area'=> 190,
                    'bedrooms'    => 5,
                    'bathrooms'   => 4,
                    'image_path'  => 'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?auto=format&fit=crop&w=1200&q=80',
                    'tagline'     => 'Panoramic Sky Terrace'
                ],
                [
                    'id'          => 3,
                    'title'       => 'The Botanica Suite',
                    'slug'        => 'the-botanica-suite',
                    'cluster_name'=> 'Eco Meadow',
                    'price'       => 1320000000,
                    'surface_area'=> 90,
                    'building_area'=> 105,
                    'bedrooms'    => 3,
                    'bathrooms'   => 2,
                    'image_path'  => 'https://images.unsplash.com/photo-1600565193348-f74bd3c7ccdf?auto=format&fit=crop&w=1200&q=80',
                    'tagline'     => 'Biophilic Green Living'
                ]
            ];
        }

        $data = [
            'title'              => $this->settings['company_name'] ?? 'Grand Harmoni Residence',
            'meta_description'   => $this->settings['company_tagline'] ?? 'Hunian Mewah, Asri, dan Strategis untuk Keluarga Idaman',
            'settings'           => $this->settings,
            'featuredProperties' => $featuredProperties,
        ];

        return view('frontend/home', $data);
    }
}
